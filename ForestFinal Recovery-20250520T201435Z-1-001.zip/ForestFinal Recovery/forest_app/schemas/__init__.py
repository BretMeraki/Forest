"""
Forest App Schemas Package

This package contains Pydantic model schemas for standardizing data models
across the application and reducing code duplication.
"""
