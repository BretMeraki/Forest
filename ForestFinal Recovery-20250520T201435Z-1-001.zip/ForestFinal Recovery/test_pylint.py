"""
Test file for Pylint.
"""


def test_function():
    """Test function."""
    print("Hello, Pylint!")
    return 42
